﻿using System;
namespace Domain.Models
{
    public class BaseEntity
    {
        public int Id { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        public void Initialize(string username)
        {
            CreatedBy = username;
            CreatedOn = DateTime.UtcNow;
        }

        public void SetModified(string username)
        {
            ModifiedBy = username;
            ModifiedOn = DateTime.UtcNow;
        }
    }
}

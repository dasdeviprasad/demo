﻿using System;

namespace Domain.Models
{
    public class Facility : BaseEntity
    {
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}

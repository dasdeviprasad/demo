﻿using System;
namespace Api.Shared.Models
{
    public class PageQueryModel
    {
        public int Page { get; set; }
        public int Size { get; set; }
        public string OrderColumn { get; set; }
        public string OrderDirection { get; set; }
    }
}

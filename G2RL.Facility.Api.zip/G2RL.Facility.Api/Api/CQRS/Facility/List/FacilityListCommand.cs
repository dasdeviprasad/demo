﻿using Api.Shared.Models;
using MediatR;

namespace Api.CQRS.Facility.List
{
    public class FacilityListCommand : IRequest<PageQueryModel>
    {
       public PageQueryModel PageQuery { get; set; }
    }
}

﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Api.Shared.Models;
using Infrastructure.Repositories.Contracts;
using MediatR;

namespace Api.CQRS.Facility.List
{
    public class FacilityListCommandHandler : IRequestHandler<FacilityListCommand, PageQueryModel>
    {
        private readonly IFacilityRepository _repo;
        private readonly string[] Facilities = {
            "F1", "F2", "F3"
        };

        public FacilityListCommandHandler(IFacilityRepository repo)
        {
            _repo = repo;
        }

        public Task<PageQueryModel> Handle(FacilityListCommand request, CancellationToken cancellationToken)
        {
            return Task.FromResult(request.PageQuery);
        }
    }
}

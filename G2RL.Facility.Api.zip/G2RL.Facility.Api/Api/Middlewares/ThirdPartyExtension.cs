﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace Api
{
    public static class ThirdPartyExtension
    {
        public static IServiceCollection EnableThirdPartyUtils(this IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup));

            // Enable Automapper
            Mapper.Reset();
            Mapper.Initialize(cfg => cfg.AddProfile<AutoMapperProfile>());
            Mapper.AssertConfigurationIsValid();

            return services;
        }
    }
}

﻿using Infrastructure.Repositories;
using Infrastructure.Repositories.Contracts;
using Microsoft.Extensions.DependencyInjection;

namespace Api
{
    public static class DependencyExtension
    {
        public static IServiceCollection InjectDependency(this IServiceCollection services)
        {
            services.AddScoped<IFacilityRepository, FacilityRepository>();

            return services;
        }
    }
}

﻿using Microsoft.Extensions.DependencyInjection;
using Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Api
{
    public static class EntityFrameworkExtension
    {
        public static IServiceCollection EnableEF(this IServiceCollection services, IConfiguration config)
        {
            string dbConnection = config.GetConnectionString("FacilityDB"); 
            services.AddDbContext<FacilityDBContext>(opt =>
                opt.UseSqlServer(dbConnection)
            );

            return services;
        }
    }
}

﻿using Microsoft.Extensions.DependencyInjection;

namespace Api
{
    public static class CorsExtension
    {
        public static IServiceCollection EnableCors(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                // this defines a CORS policy called "default"
                options.AddPolicy("default", policy =>
                {
                    policy.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });

            return services;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.CQRS.Facility.List;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FacilityController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<FacilityController> _logger;

        public FacilityController(IMediator mediator, ILogger<FacilityController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var response = await _mediator.Send(new FacilityListCommand
            {
                PageQuery = new Shared.Models.PageQueryModel { Page = 1, Size = 10 }
            });

            return new ObjectResult(response);
        }
    }
}

﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure
{
    public class FacilityDBContext : DbContext
    {
        public DbSet<Facility> Facilities { get; set; }

        public FacilityDBContext(DbContextOptions options) : base(options) { }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region Facility

            modelBuilder.Entity<Facility>()
                .HasQueryFilter(x => x.IsActive);

            modelBuilder.Entity<Facility>().Property(x => x.Name).HasMaxLength(50);
            modelBuilder.Entity<Facility>().Property(x => x.IsActive).HasDefaultValue(true);

            #endregion
        }
    }
}

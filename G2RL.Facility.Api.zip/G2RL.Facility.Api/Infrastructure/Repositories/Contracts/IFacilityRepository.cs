﻿using System.Collections.Generic;
using Domain.Models;

namespace Infrastructure.Repositories.Contracts
{
    public interface IFacilityRepository
    {
        IEnumerable<Facility> GetAll();
    }
}

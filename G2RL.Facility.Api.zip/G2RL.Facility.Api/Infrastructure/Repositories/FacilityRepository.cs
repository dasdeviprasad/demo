﻿using Domain.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Infrastructure.Repositories.Contracts;

namespace Infrastructure.Repositories
{
    public class FacilityRepository : IFacilityRepository
    {
        private readonly FacilityDBContext _context;

        public FacilityRepository(FacilityDBContext context)
        {
            _context = context;
        }

        public IEnumerable<Facility> GetAll()
        {
            return _context.Facilities.AsNoTracking()
                    .OrderBy(x => x.Name);
        }
    }
}
